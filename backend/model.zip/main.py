import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

# 3. Load the data from CSV
df = pd.read_csv("time_series_data.csv")
df["Date"] = pd.to_datetime(df["Date"])  # Convert to datetime

# 3. Prepare data for training (using 'days since start' as feature)
df["Days"] = (df["Date"] - df["Date"].min()).dt.days  # Convert dates to numerical days
X = df[["Days"]]
y = df["Value"]

# 4. Split into train and test sets
train_size = int(0.8 * len(df))
X_train, X_test = X[:train_size], X[train_size:]
y_train, y_test = y[:train_size], y[train_size:]

# 5. Train a Linear Regression model
model = LinearRegression()
model.fit(X_train, y_train)

# 6. Make predictions
y_pred = model.predict(X_test)

# 7. Plot results
plt.figure(figsize=(12, 6))
plt.plot(df["Date"], df["Value"], label="Actual Data", color="blue", alpha=0.6)
plt.plot(df["Date"][train_size:], y_pred, label="Predicted (Test Set)", color="red", linestyle="--")
plt.xlabel("Date")
plt.ylabel("Value")
plt.title("Time Series Forecasting with Linear Regression")
plt.legend()
plt.grid(True)
plt.savefig("output/time_series_forecast.png")

# 8. Evaluate model
mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error (MSE): {mse:.2f}")